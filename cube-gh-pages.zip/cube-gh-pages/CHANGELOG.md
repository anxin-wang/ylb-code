# Changelog

# V1.2.1

* \+ 更新文档
* \+ neat 更新到 v1.1.0，同步 normalize 3.0 部分更新
* \+ pre 标签默认有滚动条，为移动端增加平滑滚动

# V1.2.0

* \+ 增加 iconfont SCSS 版本
* \+ type.css 标题和 `ol` 自动编号功能，生成类似`1`, `1.1`, `1.1.1` 这样的编号。
* \+ type.css `p` 标签内链接左右增加一个英文空格。
* \* ul 默认列表项改成方块。
* \* 修复 .justify 父元素设置 line-height 导致布局错乱的 [bug #11](https://github.com/thx/cube/issues/11)
* \* 修复按钮样式。
